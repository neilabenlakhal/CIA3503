/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pkg202120_week10_observerdp;

/**
 *
 * @author nbenayed
 */
public interface Observer {
    public abstract void update();
}
