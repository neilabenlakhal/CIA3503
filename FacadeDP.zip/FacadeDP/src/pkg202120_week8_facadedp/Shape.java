/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pkg202120_week8_facadedp;

/**
 *
 * @author nbenayed
 */
public interface Shape {
    
    public abstract void draw();
    
    
}
