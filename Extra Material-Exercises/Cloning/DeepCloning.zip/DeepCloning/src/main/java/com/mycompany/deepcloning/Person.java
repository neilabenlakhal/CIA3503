/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.deepcloning;

/**
 *
 * @author reematassi
 */
   // Define the Person class
class Person implements Cloneable {
    private String name;
    private Address address;
   

    // Constructor
    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    // Getter methods

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }

    // Override the clone method for deep cloning
    @Override
    protected Object clone() throws CloneNotSupportedException {
        // Perform deep cloning by creating new instances of mutable objects
        Person clonedPerson = (Person) super.clone();
        
        clonedPerson.address = (Address) this.address.clone();
        
        return clonedPerson;
    }
}

 

