/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.deepcloning;

/**
 *
 * @author reematassi
 */
    // Define the Address class
class Address implements Cloneable {
    private String city;
    private String country;

    // Constructor
    public Address(String city, String country) {
        this.city = city;
        this.country = country;
    }

    // Getter methods

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    // Override the clone method for deep cloning
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}


