/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.deepcloning;

/**
 *
 * @author reematassi
 */
public class DeepCloning {

    public static void main(String[] args) {
        // Create an Address object
        Address address = new Address("Sharjah", "UAE");

        // Create a Person object
        Person originalPerson = new Person("Maryam", address);

        try {
            // Perform deep cloning
            Person clonedPerson = (Person) originalPerson.clone();

            // Verify the results
            System.out.println("Original Person: " + originalPerson.getName() + ", " + originalPerson.getAddress().getCity());
            System.out.println("Cloned Person: " + clonedPerson.getName() + ", " + clonedPerson.getAddress().getCity());

            // Modify the original address
            originalPerson.getAddress().setCity("Abu Dhabi");

            // Verify the independence of deep cloning on the address
            System.out.println("After modification - Original Person: " + originalPerson.getAddress().getCity());
            System.out.println("After modification - Cloned Person: " + clonedPerson.getAddress().getCity());
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}

    