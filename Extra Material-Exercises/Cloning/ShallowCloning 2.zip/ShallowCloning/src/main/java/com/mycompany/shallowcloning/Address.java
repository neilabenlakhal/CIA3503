/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shallowcloning;

/**
 *
 * @author reematassi
 */
public class Address {
    // Define the Address class
    private String city;
    private String country;

    // Constructor
    public Address(String city, String country) {
        this.city = city;
        this.country = country;
    }

    // Getter methods

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
}

