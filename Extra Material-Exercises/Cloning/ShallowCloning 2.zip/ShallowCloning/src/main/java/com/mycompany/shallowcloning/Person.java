/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shallowcloning;

/**
 *
 * @author reematassi
 */
    // Define the Person class
class Person implements Cloneable {
    private String name;
    private Address address;

    // Constructor
    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    // Getter methods

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }

    // Override the clone method for shallow cloning
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
    

