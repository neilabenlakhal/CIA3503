/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.shallowcloning;

/**
 *
 * @author reematassi
 */





public class ShallowCloning{
    public static void main(String[] args) {
        // Create an Address object
        Address address = new Address("Sharjah", "UAE");

        // Create a Person object
        Person originalPerson = new Person("Jawahir", address);

        try {
            // Perform shallow cloning
            Person clonedPerson = (Person) originalPerson.clone();

            // Verify the results
            System.out.println("Original Person: " + originalPerson.getName() + ", " + originalPerson.getAddress().getCity());
            System.out.println("Cloned Person: " + clonedPerson.getName() + ", " + clonedPerson.getAddress().getCity());

            // Modify the original address
            originalPerson.getAddress().setCity("Dubai");

            // Verify the impact of shallow cloning on the address
            System.out.println("After modification - Original Person: " + originalPerson.getAddress().getCity());
            System.out.println("After modification - Cloned Person: " + clonedPerson.getAddress().getCity());
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}




