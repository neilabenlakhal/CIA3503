/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.activity6.gui.complete;

/**
 *
 * @author ratassi
 */
public class Activity6GUIComplete {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
